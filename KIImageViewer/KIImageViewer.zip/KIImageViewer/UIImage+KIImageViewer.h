//
//  UIImage+KIImageViewer.h
//  KIImageViewer
//
//  Created by apple on 16/8/11.
//  Copyright © 2016年 SmartWalle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (KIImageViewer)

- (CGRect)centerFrameToFrame:(CGRect)frame;

@end
